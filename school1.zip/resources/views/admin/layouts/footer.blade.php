<footer class="main-footer">
 <p style="text-align: center;"><span>সকল কারিগরী সহযোগিতায় <a href="https://elitedesign.com.bd/" target="_blank"><span>এলিট ডিজাইন</span></a></span></p>
 </footer>