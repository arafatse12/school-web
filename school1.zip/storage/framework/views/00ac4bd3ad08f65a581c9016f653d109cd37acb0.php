
<?php $__env->startSection('content'); ?> 


<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row ">
          <div class="col-sm-6">
            
          </div><!-- /.col -->
        <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Home</a></li>
              <li class="breadcrumb-item active">Setting List</li>
            </ol>
          </div>
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
       <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
      
        <!-- /.row -->
        <!-- Main row -->
        <div class="row">
          <!-- Left col -->
          <section class="col-md-12">
                <div class="col-sm-6">
            <?php if($errors->any()): ?>
              <div class="alert alert-danger">
                  <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                   <button style="margin-top: -30px" type="button" class="close text-white" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              </div>
          <?php endif; ?>
        </div>
           
            <div class="pannel" style="background-color:white;border-bottom: 5px solid #605ca8 ;margin-bottom: 20px;">
             <div class="pannel-header" style="background-color: #605ca8;color: white;padding: 10px">
                <h5>Setting List
                  <?php if($alldata['0']==null): ?>
                 <button type="button" class="btn btn-warning float-right btn" data-toggle="modal" data-target="#addsetting"><i class="fa fa-plus-circle"></i> Add Setting</button>
                 <?php endif; ?>
                </h5>
              </div> 
            <div class="card-body">
                <table id="example1" class="table  table-hover table-sm">
                  <thead>
                  <tr style="background-color: #001f3f;color: white">
                     <th>College Name</th>
                     <th>Email</th>
                     <th>Mobile</th>
                     <th>Address</th>
                     <th>Status</th>
                     <th>Logo</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $alldata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                      <td><?php echo e($setting->college_name); ?></td>
                      <td><?php echo e($setting->email); ?></td>
                      <td><?php echo e($setting->mobile); ?></td>
                      <td><?php echo e($setting->address); ?></td>
                         <td>
                     <?php if($setting->status==1): ?>
                    <span class="badge badge-success">Active</span>
                    <?php else: ?>
                    <span class="badge badge-danger">Inactive</span>
                    <?php endif; ?>
                  </td>
                     <td><a target="_blank" href="<?php echo e(asset('upload/settingimage/'.$setting->logo)); ?>"><img class="profile-user-img " src="<?php echo e((!empty($setting->logo))?url('upload/settingimage/'.$setting->logo):url('upload/usernoimage.png')); ?>" style="width:40px;height: 45;" alt="User profile picture"></a></td>
                      
                  
                  <td>
                        <?php if($setting->status==1): ?>
                          <a id="inactive" href="<?php echo e(route('admin.setting.inactive',$setting->id)); ?>" class="btn  btn-warning btn-xs mr-2"> <i class="fa fa-arrow-up"></i></a>
                          <?php else: ?>
                          <a id="active" href="<?php echo e(route('admin.setting.active',$setting->id)); ?>" class="btn btn-success btn-xs mr-2" > <i class="fa fa-arrow-down"></i></a>
                          <?php endif; ?>
                    <button type="button" class="btn btn-dark  btn-xs" data-toggle="modal" data-target="#showsetting-<?php echo e($setting->id); ?>"><i class="fa fa-eye"></i></button>

                     <button type="button" class="btn btn-primary  btn-xs" data-toggle="modal" data-target="#editsetting-<?php echo e($setting->id); ?>"><i class="fa fa-edit"></i></button>

                     <a title="Delete" id="delete" href="<?php echo e(route('admin.setting.delete',$setting->id)); ?>" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></a>
                   
                      </td> 
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
                </div>
              </div>
            <!-- /.card -->

            <!-- DIRECT CHAT -->
            
          </section>
          <!-- right col -->
        </div>
        <!-- /.row (main row) -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>

   

  <div class="modal fade" id="addsetting" style="display: none;" aria-hidden="true">
        <div class="modal-dialog modal-lg">
          <div class="modal-content"style="background-color:#d9dad6;border-bottom: 5px solid #605ca8 ;">
            <div class="modal-header " style="background-color: #605ca8;color: white;padding: 10px">
              <h4 class="modal-title">Add Setting</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <div class="modal-body">
            <form method="post" action="<?php echo e(route('admin.setting.store')); ?>" id="myform" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

<div class="row">
                  <div class="form-group col-md-6">
                    <label for="college_name"  class="col-sm-12 col-form-label">College Name</label>
                    <div class="col-sm-12">
                    <input type="text" name="college_name" id="setting_college_name" class="form-control " placeholder="Enter College Name"  autocomplete="off" value="<?php echo e(old('college_name')); ?>">
                    <font style="color:red"><?php echo e(($errors)->has('college_name')?($errors->first('college_name')):''); ?></font>
                  </div>
                </div>

                <div class="form-group col-md-6">
                    <label for="email"  class="col-sm-12 col-form-label">College Email</label>
                    <div class="col-sm-12">
                    <input type="text" name="email" id="setting_email" class="form-control " placeholder="Enter College Email"  autocomplete="off" value="<?php echo e(old('email')); ?>">
                    <font style="color:red"><?php echo e(($errors)->has('email')?($errors->first('email')):''); ?></font>
                  </div>
                </div>

                <div class="form-group col-md-6">
                    <label for="mobile"  class="col-sm-12 col-form-label">College Mobile</label>
                    <div class="col-sm-12">
                    <input type="text" name="mobile" id="setting_mobile" class="form-control " placeholder="Enter College Mobile"  autocomplete="off" value="<?php echo e(old('mobile')); ?>">
                    <font style="color:red"><?php echo e(($errors)->has('mobile')?($errors->first('mobile')):''); ?></font>
                  </div>
                </div>

                 <div class="form-group col-md-6">
                    <label for="address"  class="col-sm-12 col-form-label">College Address</label>
                    <div class="col-sm-12">
                    <input type="text" name="address" id="address" class="form-control " placeholder="Enter College Address"  autocomplete="off" value="<?php echo e(old('address')); ?>">
                    <font style="color:red"><?php echo e(($errors)->has('address')?($errors->first('address')):''); ?></font>
                  </div>
                </div>

                <div class="form-group col-md-6">
                    <label for="slogan"  class="col-sm-12 col-form-label">College Slogan</label>
                    <div class="col-sm-12">
                    <input type="text" name="slogan" id="slogan" class="form-control " placeholder="Enter College Slogan"  autocomplete="off" value="<?php echo e(old('slogan')); ?>">
                    <font style="color:red"><?php echo e(($errors)->has('slogan')?($errors->first('slogan')):''); ?></font>
                  </div>
                </div>


               

                 <div class="form-group col-md-6">
                    <label for="logo"  class="col-sm-12 col-form-label">Logo</label>
                    <div class="col-sm-12">
                        <img id="showimage" src="<?php echo e((empty($setting->logo))?url('backend/settingimage/'.$setting->logo):url('upload/usernoimage.jpg')); ?>" style="width: 40px;height: 45px;border:1px solid #000;">
                    <input type="file" name="logo" id="logo" class="form-control" placeholder="Enter Image " autocomplete="off" value="<?php echo e(old('logo')); ?>">
                      <font style="color:red"><?php echo e(($errors)->has('logo')?($errors->first('logo')):''); ?></font>
                  </div>
                </div>

                
       </div>

              <div class="modal-footer ">
                 <button type="button" class="btn btn-danger "  data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-success ">Add setting</button>
             
            </div>
            </form>
            </div>
           
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- end Add Category -->
</div>
  <!-- /.content-wrapper -->
<?php $__currentLoopData = $alldata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="modal fade" id="editsetting-<?php echo e($setting->id); ?>" style="display: none;" aria-hidden="true">
        <div class="modal-dialog modal-lg">
          <div class="modal-content"style="background-color:#d9dad6;border-bottom: 5px solid #605ca8 ;">
            <div class="modal-header " style="background-color: #605ca8;color: white;padding: 10px">
              <h4 class="modal-title">Edit Setting</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <div class="modal-body">
            <form method="post" action="<?php echo e(route('admin.setting.update',$setting->id)); ?>" id="myform2" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
            <div class="row">
                  

                  <div class="form-group col-md-6">
                    <label for="college_name"  class="col-sm-12 col-form-label">College Name</label>
                    <div class="col-sm-12">
                    <input type="text" name="college_name" id="setting_college_name" class="form-control " placeholder="Enter College Name"  autocomplete="off" value="<?php echo e($setting->college_name); ?>">
                    <font style="color:red"><?php echo e(($errors)->has('college_name')?($errors->first('college_name')):''); ?></font>
                  </div>
                </div>

                <div class="form-group col-md-6">
                    <label for="email"  class="col-sm-12 col-form-label">College Email</label>
                    <div class="col-sm-12">
                    <input type="text" name="email" id="setting_email" class="form-control " placeholder="Enter College Email"  autocomplete="off" value="<?php echo e($setting->email); ?>">
                    <font style="color:red"><?php echo e(($errors)->has('email')?($errors->first('email')):''); ?></font>
                  </div>
                </div>

                <div class="form-group col-md-6">
                    <label for="mobile"  class="col-sm-12 col-form-label">College Mobile</label>
                    <div class="col-sm-12">
                    <input type="text" name="mobile" id="setting_mobile" class="form-control " placeholder="Enter College Mobile"  autocomplete="off" value="<?php echo e($setting->mobile); ?>">
                    <font style="color:red"><?php echo e(($errors)->has('mobile')?($errors->first('mobile')):''); ?></font>
                  </div>
                </div>

                 <div class="form-group col-md-6">
                    <label for="address"  class="col-sm-12 col-form-label">College Address</label>
                    <div class="col-sm-12">
                    <input type="text" name="address" id="address" class="form-control " placeholder="Enter College Address"  autocomplete="off" value="<?php echo e($setting->address); ?>">
                    <font style="color:red"><?php echo e(($errors)->has('address')?($errors->first('address')):''); ?></font>
                  </div>
                </div>
				                 <div class="form-group col-md-6">
                    <label for="meta_description"  class="col-sm-12 col-form-label">Meta description</label>
                    <div class="col-sm-12">
                    <input type="text" name="meta_description" id="meta_description" class="form-control " placeholder="Enter Meta Description"  autocomplete="off" value="<?php echo e($setting->meta_description); ?>">
                    <font style="color:red"><?php echo e(($errors)->has('meta_description')?($errors->first('meta_description')):''); ?></font>
                  </div>
                </div>
				
								                 <div class="form-group col-md-6">
                    <label for="meta_keywords"  class="col-sm-12 col-form-label">Meta Keywords</label>
                    <div class="col-sm-12">
                    <input type="text" name="meta_keywords" id="meta_keywords" class="form-control " placeholder="Enter Meta Keywords"  autocomplete="off" value="<?php echo e($setting->meta_keywords); ?>">
                    <font style="color:red"><?php echo e(($errors)->has('meta_keywords')?($errors->first('meta_keywords')):''); ?></font>
                  </div>
                </div>
												                 <div class="form-group col-md-6">
                    <label for="facebook"  class="col-sm-12 col-form-label">Facebook Page Link</label>
                    <div class="col-sm-12">
                    <input type="text" name="facebook" id="facebook" class="form-control " placeholder="Your Facebook Page URL"  autocomplete="off" value="<?php echo e($setting->facebook); ?>">
                    <font style="color:red"><?php echo e(($errors)->has('facebook')?($errors->first('facebook')):''); ?></font>
                  </div>
                </div>
												                 <div class="form-group col-md-6">
                    <label for="youtube"  class="col-sm-12 col-form-label">Youtube Chanel Link</label>
                    <div class="col-sm-12">
                    <input type="text" name="youtube" id="youtube" class="form-control " placeholder="Your Youtube chanel Link"  autocomplete="off" value="<?php echo e($setting->youtube); ?>">
                    <font style="color:red"><?php echo e(($errors)->has('youtube')?($errors->first('youtube')):''); ?></font>
                  </div>
                </div>
												                 <div class="form-group col-md-6">
                    <label for="teacher_login"  class="col-sm-12 col-form-label">Teacher Login Link</label>
                    <div class="col-sm-12">
                    <input type="text" name="teacher_login" id="teacher_login" class="form-control " placeholder="Teacher login Link"  autocomplete="off" value="<?php echo e($setting->teacher_login); ?>">
                    <font style="color:red"><?php echo e(($errors)->has('teacher_login')?($errors->first('teacher_login')):''); ?></font>
                  </div>
                </div>
												                 <div class="form-group col-md-6">
                    <label for="student_login"  class="col-sm-12 col-form-label">Student Login Link</label>
                    <div class="col-sm-12">
                    <input type="text" name="student_login" id="student_login" class="form-control " placeholder="Student Login Link"  autocomplete="off" value="<?php echo e($setting->student_login); ?>">
                    <font style="color:red"><?php echo e(($errors)->has('student_login')?($errors->first('student_login')):''); ?></font>
                  </div>
                </div>
				
																                 <div class="form-group col-md-6">
                    <label for="admit_card"  class="col-sm-12 col-form-label">Admit Card Link</label>
                    <div class="col-sm-12">
                    <input type="text" name="admit_card" id="admit_card" class="form-control " placeholder="Admit Link"  autocomplete="off" value="<?php echo e($setting->admit_card); ?>">
                    <font style="color:red"><?php echo e(($errors)->has('admit_card')?($errors->first('admit_card')):''); ?></font>
                  </div>
                </div>
				
																				                 <div class="form-group col-md-6">
                    <label for="result"  class="col-sm-12 col-form-label">Result Link</label>
                    <div class="col-sm-12">
                    <input type="text" name="result" id="result" class="form-control " placeholder="Result Link"  autocomplete="off" value="<?php echo e($setting->result); ?>">
                    <font style="color:red"><?php echo e(($errors)->has('result')?($errors->first('result')):''); ?></font>
                  </div>
                </div>
				
																								                 <div class="form-group col-md-6">
                    <label for="certificate"  class="col-sm-12 col-form-label">Certificate Link</label>
                    <div class="col-sm-12">
                    <input type="text" name="certificate" id="certificate" class="form-control " placeholder="Certificate Link"  autocomplete="off" value="<?php echo e($setting->certificate); ?>">
                    <font style="color:red"><?php echo e(($errors)->has('certificate')?($errors->first('certificate')):''); ?></font>
                  </div>
                </div>
				
																												                 <div class="form-group col-md-6">
                    <label for="admission_link"  class="col-sm-12 col-form-label">Admission Link</label>
                    <div class="col-sm-12">
                    <input type="text" name="admission_link" id="admission_link" class="form-control " placeholder="Admission Link"  autocomplete="off" value="<?php echo e($setting->admission_link); ?>">
                    <font style="color:red"><?php echo e(($errors)->has('admission_link')?($errors->first('admission_link')):''); ?></font>
                  </div>
                </div>

                <div class="form-group col-md-6">
                    <label for="slogan"  class="col-sm-12 col-form-label">College Slogan</label>
                    <div class="col-sm-12">
                    <input type="text" name="slogan" id="slogan" class="form-control " placeholder="Enter College Slogan"  autocomplete="off" value="<?php echo e($setting->slogan); ?>">
                    <font style="color:red"><?php echo e(($errors)->has('slogan')?($errors->first('slogan')):''); ?></font>
                  </div>
                </div>

             

                 <div class="form-group col-md-6">
                    <label for="logo"  class="col-sm-12 col-form-label">Logo</label>
                    <div class="col-sm-12">
                        <img id="showimage2" src="<?php echo e((!empty($setting->logo))?url('upload/settingimage/'.$setting->logo):url('upload/usernoimage.jpg')); ?>" style="width: 40px;height: 45px;border:1px solid #000;">
                    <input type="file" name="logo" id="logo" class="form-control" placeholder="Enter Image " autocomplete="off" value="<?php echo e($setting->logo); ?>">
                      <font style="color:red"><?php echo e(($errors)->has('logo')?($errors->first('logo')):''); ?></font>
                  </div>
                </div>


                
       </div>
           

              <div class="modal-footer ">
                 <button type="button" class="btn btn-danger "  data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-success ">Update setting</button>
             
            </div>
            </form>
            </div>
           
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- end Add Category -->
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

 <!-- /.content-wrapper -->
<?php $__currentLoopData = $alldata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="modal fade" id="showsetting-<?php echo e($setting->id); ?>" style="display: none;" aria-hidden="true">
        <div class="modal-dialog modal-small">
          <div class="modal-content"style="background-color:#d9dad6;border-bottom: 5px solid #605ca8 ;">
            <div class="modal-header " style="background-color: #605ca8;color: white;padding: 10px">
              <h4 class="modal-title"> setting Details</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <div class="modal-body">
           
           <table class="table table-bordered table-hover table-sm" >
            <tr>
              <th width="30%">setting ID</th>
              <th width="70%"><?php echo e($setting->id); ?></th>
            </tr>
            <tr>
              <th width="30%"> setting Title</th>
              <th width="70%"><?php echo e($setting->title); ?></th>
            </tr>
            
             <tr>
              <th width="30%"> setting</th>
               <td><a target="_blank" href="<?php echo e(asset('upload/settingimage/'.$setting->logo)); ?>"><img class="profile-user-img " src="<?php echo e((!empty($setting->logo))?url('upload/settinglogo/'.$setting->logo):url('upload/usernoimage.png')); ?>" style="width:120px;height: 150;" alt="User profile picture"></a></td>
                      <td>
            </tr>
           </table>
                  

              <div class="modal-footer ">
                 <button type="button" class="btn btn-danger "  data-dismiss="modal">Close</button>
            </div>
           
            </div>
           
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- end Add Category -->
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

 <script>
        $('#datepicker').datepicker({
            uiLibrary: 'bootstrap4',
            format:'yyyy-mm-dd'
        });
    </script>
    <script>
        $('#datepicker2').datepicker({
            uiLibrary: 'bootstrap4',
            format:'yyyy-mm-dd'
        });
    </script>

  <script>
$(function () {
  
  $('#myform').validate({
    rules: {

      class_id: {
      required: true,
        
      },
      title: {
        required: true,
        
      },
      category_id: {
        required: true,
        
      },
      post_file: {
        required: true,
        
      },

      description: {
      required: true,
        
      },
       
      post_date: {
      required: true,
        
      },


      email: {
        required: true,
        email: true
       
    
        
      }
    },
    messages: {
      email: {
        required: "Please enter a email address",
        email: "Please enter a vaild email address"
        
      },

      name: {
        required: "Please enter Name",
        
      }
      
      
   
    },
    errorElement: 'span',
    errorPlacement: function (error, element) {
      error.addClass('invalid-feedback');
      element.closest('.form-group').append(error);
    },
    highlight: function (element, errorClass, validClass) {
      $(element).addClass('is-invalid');
    },
    unhighlight: function (element, errorClass, validClass) {
      $(element).removeClass('is-invalid');
    }
  });
});
</script>

 <script>
$(function () {
  
  $('#myform2').validate({
    rules: {

      role_id: {
      required: true,
        
      },
      name: {
        required: true,
        
      },
      mobile: {
        required: true,
        
      },
      gender: {
        required: true,
        
      },
       
      address: {
      required: true,
        
      },


      email: {
        required: true,
        email: true
       
    
        
      }
    },
    messages: {
      email: {
        required: "Please enter a email address",
        email: "Please enter a vaild email address"
        
      },

      name: {
        required: "Please enter Name",
        
      }
      
      
   
    },
    errorElement: 'span',
    errorPlacement: function (error, element) {
      error.addClass('invalid-feedback');
      element.closest('.form-group').append(error);
    },
    highlight: function (element, errorClass, validClass) {
      $(element).addClass('is-invalid');
    },
    unhighlight: function (element, errorClass, validClass) {
      $(element).removeClass('is-invalid');
    }
  });
});
</script>

<script>
        $('#datepicker').datepicker({
            uiLibrary: 'bootstrap4',
            format:'yyyy-mm-dd'
        });
    </script>
    <script>
        $('#datepicker2').datepicker({
            uiLibrary: 'bootstrap4',
            format:'yyyy-mm-dd'
        });
    </script>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\school1\resources\views/admin/setting/view-setting.blade.php ENDPATH**/ ?>