 

 <?php $__env->startSection('content'); ?>
<?php echo $__env->make('frontend.layouts.notice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="row">
   

</div>
 <div class="row">

		<div id="box-1" class="six columns service-box box" style="height: auto;">
		<h4>ক্যাম্পাস</h4>
		<img src="<?php echo e(asset('frontend')); ?>/assets/images/icon/campus.png" alt="" width="100" height=""/>
		<ul class="caption fade-caption" style="margin:0">
        <li><a href="<?php echo e(route('history')); ?>">ইতিহাস</a></li>
        <li><a href="<?php echo e(route('structure')); ?>">প্রাতিষ্ঠানিক কাঠামো </a></li>
        <li><a href="<?php echo e(route('infrastructure')); ?>">প্রাতিষ্ঠানিক অবকাঠামো</a></li>
        <li><a href="<?php echo e(route('purification')); ?>">শুদ্ধাচার সংক্রান্ত তথ্য</a></li>
                    
		</ul>
	</div>
			<div id="box-2" class="six columns service-box box" style="height: auto;">
		<h4>ভর্তি</h4>
		<img src="<?php echo e(asset('frontend')); ?>/assets/images/icon/admission512x512.png" alt="" width="100" height=""/>
		<ul class="caption fade-caption" style="margin:0">
            <li><a href="<?php echo e(route('admission.exam')); ?>">ভর্তি পরীক্ষা</a></li>
            <li><a href="<?php echo e(route('admission.rules')); ?>">ভর্তি নীতি</a></li>
            <li><a href="<?php echo e(route('registration')); ?>">রেজিস্ট্রেশন সিস্টেম</a></li>
            <li><a href="<?php echo e(route('curricullam')); ?>">বর্তমান শিক্ষা ব্যবস্থা</a></li>
</ul>
	</div>
		</div>

			<div class="row">
		<div id="box-3" class="six columns service-box box" style="height: auto;">
		<h4>একাডেমিক</h4>
		<img src="<?php echo e(asset('frontend')); ?>/assets/images/icon/scholarship.png" alt="" width="100" height=""/>
		<ul class="caption fade-caption" style="margin:0">
        <li><a href="<?php echo e(route('founder')); ?>">প্রতিষ্ঠাতা</a></li>
        <li><a href="<?php echo e(route('teacher')); ?>">শিক্ষক</a></li>
        <li><a href="<?php echo e(route('office')); ?>">অফিস</a></li>
         <li><a href="<?php echo e(route('stuff')); ?>"> কর্মচারী</a></li>
		</ul>
	</div>
			<div id="box-4" class="six columns service-box box" style="height: auto;">
		<h4>একাডেমিক পেপার</h4>
		<img src="<?php echo e(asset('frontend')); ?>/assets/images/icon/academic_paper.png" alt="" width="100" height=""/>
		<ul class="caption fade-caption" style="margin:0">
            
    <li><a href="<?php echo e(route('class-routine')); ?>">শ্রেণীসূচি</a></li>
    <li><a href="<?php echo e(route('online-class-routine')); ?>">অনলাইন শ্রেণীসূচি</a></li>
    <li><a href="<?php echo e(route('class-routine')); ?>">পরীক্ষার সময়সূচি</a></li>
    <li><a href="<?php echo e(route('academic-syllabus')); ?>">একাডেমিক সিলেবাস</a></li>
    <li><a href="<?php echo e(route('calendar')); ?>">শিক্ষা বর্ষপঞ্জি</a></li>
    <li><a href="<?php echo e(route('prospectus')); ?>">একাডেমিক প্রসপেক্টাস</a></li>
</ul>
	</div>
		</div>
			<div class="row">
		<div id="box-5" class="six columns service-box box" style="height: 100%;">
		<h4>শিক্ষার্থী</h4>
		<img src="<?php echo e(asset('frontend')); ?>/assets/images/icon/Examination_ex.png" alt="" width="100" height=""/>
		<ul class="caption fade-caption" style="margin:0">
         <li><a href="<?php echo e(route('tution')); ?>">শিক্ষার্থীদের বেতন</a></li>
        <li><a href="<?php echo e(route('exam-manage')); ?>">পরীক্ষার ব্যবস্থা</a></li>
        <li><a href="<?php echo e(route('our-student')); ?>">আমাদের ছাত্র-ছাত্রী</a></li>
   </ul>
	</div>


			<div id="box-6" class="six columns service-box box" style="height: 100%;"   >
		<h4>ফলাফল</h4>
		<img src="<?php echo e(asset('frontend')); ?>/assets/images/icon/GPA-512.png" alt="" width="100" height=""/>
		<ul class="caption fade-caption" style="margin:0">
        <li><a href="<?php echo e(route('result.notice')); ?>">একাডেমিক পরীক্ষার ফলাফল</a></li>
                <li><a target="_blank" href="https://eboardresults.com/v2/home">বোর্ড পরীক্ষার ফলাফল</a></li>
                <li><a href="<?php echo e(route('student-rules')); ?>"></a></li>
        <li><a href="<?php echo e(route('our-student')); ?>"></a></li>
        <li><a href="<?php echo e(route('student-success')); ?>"></a></li>
        <li><a href="<?php echo e(route('student-success')); ?>"></a></li>
	</ul>
	</div>
		</div>


    <div class="row">
        <div id="box-7" class="six columns service-box box" style="height: auto;">
            <h4>নোটিশ</h4>
            <img src="<?php echo e(asset('frontend')); ?>/assets/images/icon/notice%26download.png" alt="" width="100" height=""/>
            
            <ul class="caption fade-caption" style="margin:0">
                <li><a href="<?php echo e(route('admission.notice')); ?>">ভর্তি নোটিশ</a></li>
                <li><a href="<?php echo e(route('exam.notice')); ?>">পরীক্ষার নোটিশ</a></li>
                <li><a href="<?php echo e(route('result.notice')); ?>">ফলাফলের নোটিশ</a></li>
                <li><a href="<?php echo e(route('event.notice')); ?>">ইভেন্টস নোটিশ</a></li>
                <li><a href="<?php echo e(route('admin.notice')); ?>">প্রশাসন নোটিশ</a></li>
                <li><a href="<?php echo e(route('national.notice')); ?>">জাতীয় কর্মসূচী</a></li>

                
            </ul>
        </div>

        <div id="box-8" class="six columns service-box box" style="height: auto;">
            <h4>কোর্সসমূহ</h4>
            <img src="<?php echo e(asset('frontend')); ?>/assets/images/icon/course-list.png" alt="" width="100" height=""/>
            <ul class="caption fade-caption" style="margin:0">
            <li><a href="<?php echo e(route('high')); ?>">৬ষ্ঠ - দশম</a></li>
            </ul>
        </div>
    </div>

     <div class="row">
        <div id="box-7" class="six columns service-box box" style="height: auto;">
            <h4>বৃত্তি ও উপবৃত্তি</h4>
            <img src="<?php echo e(asset('frontend')); ?>/assets/images/icon/notice%26download.png" alt="" width="100" height=""/>
            
            <ul class="caption fade-caption" style="margin:0">
             <li><a href="<?php echo e(route('schollar.notice')); ?>">বৃত্তি সংক্রান্ত নোটিশ</a></li>
            <li><a href="<?php echo e(route('stipend.notice')); ?>">উপবৃত্তি সংক্রান্ত নোটিশ</a></li>

            </ul>
        </div>

        <div id="box-8" class="six columns service-box box" style="height: auto;">
            <h4>যোগাযোগ</h4>
            <img src="<?php echo e(asset('frontend')); ?>/assets/images/icon/course-list.png" alt="" width="100" height=""/>
            <ul class="caption fade-caption" style="margin:0">
            <li><a  href="<?php echo e(route('contact.view')); ?>">প্রতিষ্ঠানের ঠিকানা</a></li>
            <li><a target="_blank" href="<?php echo e($setting->facebook); ?>">ফেজবুক পেইজ</a></li>
            <li><a target="_blank" href="<?php echo e($setting->youtube); ?>">ইউটিউব চ্যানেল</a></li>
            
            </ul>
        </div>
    </div>

    <div class="row">
<div id="box-7" class="six columns service-box box" style="height: auto;">
<h4>রিসোর্স</h4>
<img src="<?php echo e(asset('frontend')); ?>/assets/images/icon/resources-.png" alt="" width="100" height=""/>
<ul class="caption fade-caption" style="margin:0">
            <li><a href="<?php echo e(route('class-content')); ?>">ডিজিটাল ক্লাস কনটেন্ট</a></li>
             <li><a href="<?php echo e(route('library')); ?>">গ্রন্থাগার</a></li>
            <li><a href="<?php echo e(route('labrotory')); ?>">গবেষণাগার</a></li>
            <li><a href="<?php echo e(route('sports-yard')); ?>">খেলার মাঠ</a></li>
            <li><a href="<?php echo e(route('co-education')); ?>">সহ-পাঠক্রম সংক্রান্ত কার্যক্রম</a></li>
</ul>
</div>
    <div id="box-8" class="six columns service-box box" style="height: auto;">
<h4>গ্যালারী</h4>
<img src="<?php echo e(asset('frontend')); ?>/assets/images/icon/gallery-44-267592.png" alt="" width="100" height=""/>
<ul class="caption fade-caption" style="margin:0">
<li><a href="<?php echo e(route('photo.gallery')); ?>">ফটো গ্যালারী</a></li>
<li><a href="<?php echo e(route('video.gallery')); ?>">ভিডিও গ্যালারী</a></li>
</ul>
    </div>
</div>




    <?php echo $__env->make('frontend.layouts.gallery', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\school1\resources\views/frontend/layouts/home.blade.php ENDPATH**/ ?>