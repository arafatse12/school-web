 

 <?php $__env->startSection('content'); ?>

<div id="contents" class="sixteen columns">

	<div class="twelve columns" id="left-content">
	<br>
	
	<h4 style="font-weight: bold;">কর্মচারীগণ :</h4>
	<hr>
  <div style="text-align: justify;">
            <p><?php echo $academic->helper; ?></p>
        </div>


</div>

 <?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\school1\resources\views/frontend/single/academic/stuff.blade.php ENDPATH**/ ?>