
<?php $__env->startSection('content'); ?> 


<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row ">
          <div class="col-sm-6">
            
          </div><!-- /.col -->
        <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Home</a></li>
              <li class="breadcrumb-item active">Teacher List</li>
            </ol>
          </div>
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
       <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
      
        <!-- /.row -->
        <!-- Main row -->
        <div class="row">
          <!-- Left col -->
          <section class="col-md-12">
                <div class="col-sm-6">
            <?php if($errors->any()): ?>
              <div class="alert alert-danger">
                  <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                   <button style="margin-top: -30px" type="button" class="close text-white" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              </div>
          <?php endif; ?>
        </div>
           
            <div class="pannel" style="background-color:white;border-bottom: 5px solid #605ca8 ;margin-bottom: 20px;">
             <div class="pannel-header" style="background-color: #605ca8;color: white;padding: 10px">
                <h5>Teacher List
                 <button type="button" class="btn btn-warning float-right btn" data-toggle="modal" data-target="#addTeacher"><i class="fa fa-plus-circle"></i> Add Teacher</button>
                </h5>
              </div> 
            <div class="card-body">
                <table id="example1" class="table  table-hover table-sm">
                  <thead>
                  <tr style="background-color: #001f3f;color: white">
                    <th>SL</th>
                    <th>ID</th>
                    <th>User Type</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Mobile</th>
                    <th>Code</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $alldata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                      <td><?php echo e($key+1); ?></td>
                      <td><?php echo e($user->id); ?></td>
                      <td><?php echo e($user['role']['name']); ?></td>
                      <td><?php echo e($user->name); ?></td>
                      <td><?php echo e($user->email); ?></td>
                      <td><?php echo e($user->mobile); ?></td>
                     <td><?php echo e($user->code); ?></td>
                      <td>
                     <?php if($user->status==1): ?>
                    <span class="badge badge-success">Active</span>
                    <?php else: ?>
                    <span class="badge badge-danger">Inactive</span>
                    <?php endif; ?>
                  </td>
                      <td>
                         <?php if($user->status==1): ?>
                          <a id="inactive" href="<?php echo e(route('admin.teacher.inactive',$user->id)); ?>" class="btn  btn-warning btn-xs mr-2"> <i class="fa fa-arrow-up"></i></a>
                          <?php else: ?>
                          <a id="active" href="<?php echo e(route('admin.teacher.active',$user->id)); ?>" class="btn btn-success btn-xs mr-2" > <i class="fa fa-arrow-down"></i></a>
                          <?php endif; ?>

                    
                    <button type="button" class="btn btn-dark  btn-xs" data-toggle="modal" data-target="#showTeacher-<?php echo e($user->id); ?>"><i class="fa fa-eye"></i></button>

                     <button type="button" class="btn btn-primary  btn-xs" data-toggle="modal" data-target="#editTeacher-<?php echo e($user->id); ?>"><i class="fa fa-edit"></i></button>

                    <a title="Delete" id="delete" href="<?php echo e(route('admin.teacher.delete',$user->id)); ?>" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></a>
                      </td> 
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
                </div>
              </div>
            <!-- /.card -->

            <!-- DIRECT CHAT -->
            
          </section>
          <!-- right col -->
        </div>
        <!-- /.row (main row) -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>

   

  <div class="modal fade" id="addTeacher" style="display: none;" aria-hidden="true">
        <div class="modal-dialog modal-small">
          <div class="modal-content"style="background-color:#d9dad6;border-bottom: 5px solid #605ca8 ;">
            <div class="modal-header " style="background-color: #605ca8;color: white;padding: 10px">
              <h4 class="modal-title">Add Teacher</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <div class="modal-body">
            <form method="post" action="<?php echo e(route('admin.teacher.store')); ?>" id="myform">
                <?php echo csrf_field(); ?>
                
                <div class="form-group row">
                    <label for="role_id"  class="col-sm-3 col-form-label">Role Name</label>
                  <div class="col-sm-9">
                    <select name="role_id" id="role_id" class="form-control" autocomplete="off" value="<?php echo e(old('role_id')); ?>">
                      <option value="">Select Role Name</option>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                     <font style="color:red"><?php echo e(($errors)->has('role_id')?($errors->first('role_id')):''); ?></font>
                  </div>
                   </div>


                  <div class="form-group row">
                     <label for="name"  class="col-sm-3 col-form-label">Name</label>
                 <div class="col-sm-9">
                    <input type="text" name="name" id="name" class="form-control" placeholder="Enter Name" autocomplete="off" value="<?php echo e(old('name')); ?>">
                     <font style="color:red"><?php echo e(($errors)->has('name')?($errors->first('name')):''); ?></font>
                  </div>
                </div>

                  <div class="form-group row">
                    <label for="email"  class="col-sm-3 col-form-label">Email</label>
                    <div class="col-sm-9">
                    <input type="email" name="email" id="email" class="form-control" placeholder="Enter Email" autocomplete="off" value="<?php echo e(old('email')); ?>">
                    <font style="color:red"><?php echo e(($errors)->has('email')?($errors->first('email')):''); ?></font>
                  </div>
                </div>

                  

                  <div class="form-group row">
                    <label for="mobile"  class="col-sm-3 col-form-label">Mobile</label>
                    <div class="col-sm-9">
                    <input type="text" name="mobile" id="mobile" class="form-control" placeholder="Enter Mobile Number" autocomplete="off" value="<?php echo e(old('mobile')); ?>">
                      <font style="color:red"><?php echo e(($errors)->has('mobile')?($errors->first('mobile')):''); ?></font>
                  </div>
                </div>
           

              <div class="modal-footer ">
                 <button type="button" class="btn btn-danger "  data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-success ">Add Teacher</button>
             
            </div>
            </form>
            </div>
           
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- end Add Category -->
</div>
  <!-- /.content-wrapper -->
<?php $__currentLoopData = $alldata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="modal fade" id="editTeacher-<?php echo e($user->id); ?>" style="display: none;" aria-hidden="true">
        <div class="modal-dialog modal-small">
          <div class="modal-content"style="background-color:#d9dad6;border-bottom: 5px solid #605ca8 ;">
            <div class="modal-header " style="background-color: #605ca8;color: white;padding: 10px">
              <h4 class="modal-title">Edit Teacher</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <div class="modal-body">
            <form method="post" action="<?php echo e(route('admin.teacher.update',$user->id)); ?>" id="myform2">
                <?php echo csrf_field(); ?>
                
                <div class="form-group row">
                    <label for="role_id"  class="col-sm-3 col-form-label">Role Name</label>
                  <div class="col-sm-9">
                    <select name="role_id" id="role_id" class="form-control" autocomplete="off">
                      <option value="">Select Role Name</option>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($role->id); ?>" <?php echo e($role->id == $user->role_id ?" selected":""); ?>><?php echo e($role->name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                     <font style="color:red"><?php echo e(($errors)->has('role_id')?($errors->first('role_id')):''); ?></font>
                  </div>
                   </div>


                  <div class="form-group row">
                     <label for="name"  class="col-sm-3 col-form-label">Name</label>
                 <div class="col-sm-9">
                    <input type="text" name="name" value="<?php echo e($user->name); ?>" id="name" class="form-control" placeholder="Enter Name" autocomplete="off">
                     <font style="color:red"><?php echo e(($errors)->has('name')?($errors->first('name')):''); ?></font>
                  </div>
                </div>

                  <div class="form-group row">
                    <label for="email"  class="col-sm-3 col-form-label">Email</label>
                    <div class="col-sm-9">
                    <input type="email" value="<?php echo e($user->email); ?>" name="email" id="email" class="form-control" placeholder="Enter Email" autocomplete="off">
                    <font style="color:red"><?php echo e(($errors)->has('email')?($errors->first('email')):''); ?></font>
                  </div>
                </div>


                
                  <div class="form-group row">
                    <label for="mobile"  class="col-sm-3 col-form-label">Mobile</label>
                    <div class="col-sm-9">
                    <input type="text" name="mobile" value="<?php echo e($user->mobile); ?>" id="mobile2" class="form-control" placeholder="Enter Mobile Number" autocomplete="off">
                      <font style="color:red"><?php echo e(($errors)->has('mobile')?($errors->first('mobile')):''); ?></font>
                  </div>
                </div>
           

              <div class="modal-footer ">
                 <button type="button" class="btn btn-danger "  data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-warning ">Update Teacher</button>
             
            </div>
            </form>
            </div>
           
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- end Add Category -->
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

 <!-- /.content-wrapper -->
<?php $__currentLoopData = $alldata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="modal fade" id="showTeacher-<?php echo e($user->id); ?>" style="display: none;" aria-hidden="true">
        <div class="modal-dialog modal-small">
          <div class="modal-content"style="background-color:#d9dad6;border-bottom: 5px solid #605ca8 ;">
            <div class="modal-header " style="background-color: #605ca8;color: white;padding: 10px">
              <h4 class="modal-title"> Teacher Details</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <div class="modal-body">
           
           <table class="table table-bordered table-hover table-sm" >
            <tr>
              <th width="30%">Teacher ID</th>
              <th width="70%"><?php echo e($user->id); ?></th>
            </tr>
            <tr>
              <th width="30%"> Name</th>
              <th width="70%"><?php echo e($user->name); ?></th>
            </tr>
            <tr>
              <th width="30%">Email</th>
              <th width="70%"><?php echo e($user->email); ?></th>
            </tr>
            <tr>
              <th width="30%"> Mobile</th>
              <th width="70%"><?php echo e($user->mobile); ?></th>
            </tr>
            <tr>
              <th width="30%">Address</th>
              <th width="70%"><?php echo e($user->address); ?></th>
            </tr>
             <tr>
              <th width="30%">Teacher Photo</th>
               <td>
                        <?php if($user->role_id == 1): ?>
                        <img style="width: 80px;height: 100px" class="profile-user-img img-fluid "
                       src="<?php echo e((!empty($user->image))?url('upload/adminimage/'.$user->image):url('upload/userimage.png')); ?>"
                       alt="User profile picture">
                       <?php elseif($user->role_id == 2): ?>
                        <img style="width: 80px;height: 100px" class="profile-user-img img-fluid "
                       src="<?php echo e((!empty($user->image))?url('upload/librarianimage/'.$user->image):url('upload/userimage.png')); ?>"
                       alt="User profile picture">
                        <?php elseif($user->role_id == 3): ?>
                        <img style="width: 80px;height: 100px" class="profile-user-img img-fluid "
                       src="<?php echo e((!empty($user->image))?url('upload/userimage/'.$user->image):url('upload/userimage.png')); ?>"
                       alt="User profile picture">
                       <?php endif; ?>

                     </td>
            </tr>
           </table>
                  

              <div class="modal-footer ">
                 <button type="button" class="btn btn-danger "  data-dismiss="modal">Close</button>
            </div>
           
            </div>
           
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- end Add Category -->
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <script>
$(function () {
  
  $('#myform').validate({
    rules: {

      role_id: {
      required: true,
        
      },
      name: {
        required: true,
        
      },
      mobile2: {
        required: true,
        
      },
      gender: {
        required: true,
        
      },
       
      address: {
      required: true,
        
      },


      email: {
        required: true,
        email: true
       
    
        
      }
    },
    messages: {
      email: {
        required: "Please enter a email address",
        email: "Please enter a vaild email address"
        
      },

      name: {
        required: "Please enter Name",
        
      }
      
      
   
    },
    errorElement: 'span',
    errorPlacement: function (error, element) {
      error.addClass('invalid-feedback');
      element.closest('.form-group').append(error);
    },
    highlight: function (element, errorClass, validClass) {
      $(element).addClass('is-invalid');
    },
    unhighlight: function (element, errorClass, validClass) {
      $(element).removeClass('is-invalid');
    }
  });
});
</script>

 <script>
$(function () {
  
  $('#myform2').validate({
    rules: {

      role_id: {
      required: true,
        
      },
      name: {
        required: true,
        
      },
      mobile: {
        required: true,
        
      },
      gender: {
        required: true,
        
      },
       
      address: {
      required: true,
        
      },


      email: {
        required: true,
        email: true
       
    
        
      }
    },
    messages: {
      email: {
        required: "Please enter a email address",
        email: "Please enter a vaild email address"
        
      },

      name: {
        required: "Please enter Name",
        
      }
      
      
   
    },
    errorElement: 'span',
    errorPlacement: function (error, element) {
      error.addClass('invalid-feedback');
      element.closest('.form-group').append(error);
    },
    highlight: function (element, errorClass, validClass) {
      $(element).addClass('is-invalid');
    },
    unhighlight: function (element, errorClass, validClass) {
      $(element).removeClass('is-invalid');
    }
  });
});
</script>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\school1\resources\views/admin/teacher/view-teacher.blade.php ENDPATH**/ ?>