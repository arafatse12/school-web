 

 <?php $__env->startSection('content'); ?>

<div id="contents" class="sixteen columns">

	<div class="twelve columns" id="left-content">
	<br>
	
	<h2 style="font-weight: bold;font-size:25px"> প্রশাসনিক নোটিশ </h2>
	
	<hr>
	
  <div >
  	<style>
		nav svg{
			height: 20px;

		}
		nav .hidden{
			display: block !important ;
		}
	</style>

    <?php if($admins->isEmpty()): ?>
     <h4 style="color:red">Data Not Found!!!</h4>
      <?php else: ?>

  	 <table class="table table-bordered table-hover" id="example" width="100%">
                <thead>
                <tr style="background-color: #001f3f;color: white;font-weight:bold;">
                    <td width="5%">Sl</td>
                    <td width="15%">Notice Date</td>
                    <td width="65%">Title</td>
                    <td width="15%">Notice Files</td>
                </tr>
                </thead>
                <tbody>
                	<?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                   <td><?php echo e($key+1); ?></td>
                   <td style="font-weight: bold;"><?php echo e(date('d-M-Y',strtotime($post->post_date))); ?></td>
                   <td>
                      <h5 style="font-weight: bold;"><a href="<?php echo e(route('post.details',$post->id)); ?>"><?php echo Str::words($post->title, 20); ?></a></h5>
                      
                   </td>
                      <td><a style="color:blue" href="<?php echo e(asset('upload/postfile/'.$post->post_file)); ?>"><i  class="fa fa-file-pdf-o" style="color:red;font-size:20px;margin-right: 5px;"></i>ডাউনলোড</a>

                    </td>
                  </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>      
                 </tbody>
            </table>

            <?php echo e($admins->links()); ?>

    <?php endif; ?>
   </div>


</div>

 <?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\school1\resources\views/frontend/single/post/admin-notice.blade.php ENDPATH**/ ?>