 

 <?php $__env->startSection('content'); ?>

<div id="contents" class="sixteen columns">
<style>
    nav svg{
      height: 20px;

    }
    nav .hidden{
      display: block !important ;
    }
  </style>
	<div class="twelve columns" id="left-content">
	<br>
	
	<h2 style="font-weight: bold;font-size:25px"> ভিডিও গ্যালারী </h2>
	
	<hr>

         <div class="row">
                   
        <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <div class="four columns columns" style="text-align: center;">
            <div class="row">
        <div style="padding: 5px;" class="col-md-4">
            <iframe frameborder="0"  width="100%"  src="<?php echo e($video->link); ?>"></iframe>
        </div>
        </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

         <?php echo e($videos->links()); ?>

      </div>
	
</div>


 <?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\school1\resources\views/frontend/single/gallery/video-gallery.blade.php ENDPATH**/ ?>