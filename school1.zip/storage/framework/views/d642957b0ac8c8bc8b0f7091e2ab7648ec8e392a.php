<div class="footer-artwork" id="footer-artwork">&nbsp;</div>
<div class="footer-wrapper full-width" id="footer-wrapper">
    <div id="footer-menu">
        <span style="font-weight: bold;"><?php echo e($setting->college_name); ?> </span>
        <br>
        <span>ঠিকানাঃ <?php echo e($setting->address); ?></span>
        <br>
        <span>মোবাইলঃ <?php echo e($setting->mobile); ?></span>
        <br>
        <span>ইমেইলঃ <?php echo e($setting->email); ?></span>
        

    </div>

    <div class="footer-credit" id="footer">
        <!--  -->

        <span style="font-weight: bold;">সকল কারিগরি সহযোগিতায়</span>
        <br>
        <span style="font-weight: bold; font-size: 14px;"><a href="http://www.elitedesign.com.bd" target="_blank"> এলিট ডিজাইন</a></span><br>
        <span style="font-weight: bold;">বড়বাড়ি, লালমনির হাট</span>
        <span style="font-weight: bold;">মোবাইল : ০১৭৭৫৪৫৭০০৮, ০১৯৫৪৫৭৮০৮৯</span>


        <br>
        <span style="font-weight: bold;">ওয়েব সাইট ডিজাইন</span>
        <span style="font-weight: bold; font-size: 14px;"><a href="http://www.elitedesign.com.bd" target="_blank"> এলিট ডিজাইন</a></span><br>
    </div>
    <!-- /footer -->
</div><?php /**PATH C:\laragon\www\school1\resources\views/frontend/layouts/footer.blade.php ENDPATH**/ ?>